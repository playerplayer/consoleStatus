import java.util.*;
import java.util.regex.*;
import java.io.*;  
import java.awt.*;
//import javax.swing.*;
import java.net.*;
public class Main 
{
	public static String[] findFaceit(long[] result, int arrayLength)
	{
		String[] faceitUrl = new String[arrayLength];
		for(int i = 0; i < arrayLength; i++)
		{
			faceitUrl[i] = "https://www.faceit.com/en/search/overview/" + result[i]; 
		}
		return faceitUrl;
	}
	public static String[] findEsea(String[] steamarray, int arrayLength) 
	{
		String[] eseaUrl = new String[arrayLength];
		
		for(int i = 0; i < arrayLength; i++)
		{
			eseaUrl[i] = "https://play.esea.net/index.php?s=search&source=users&query=1:" + steamarray[i]; 
			//System.out.println(steamarray[i]);
		}
		return eseaUrl;
	}
    public static long[] toBinary(String[] steamarray, int arrayLength)
    {
    	int[] server = new int[arrayLength];
    	int[] actualID = new int[arrayLength];
	    long[] binary = new long[arrayLength];
	    String[] fullformat = new String[arrayLength];
    	String[][] converter = new String[arrayLength][2];
        for(int i = 0; i < steamarray.length; i++)
        {
	    	steamarray[i] = steamarray[i].replace("STEAM_0:", "");
	        steamarray[i] = steamarray[i].replace("STEAM_1:", "");
	        
        }
	    for(int i = 0; i < arrayLength; i++)
	    {
	    	for(int j = 0; j < 2; j++)
	    	{
	    		converter[i] = steamarray[i].split(":",2);
	    		
	    	}
	    	
	    	
	    }
	    //servers and actual IDs
	    for(int i = 0; i < arrayLength; i++)
	    {
	    	server[i] = Integer.parseInt(converter[i][0]);
	    	actualID[i] = Integer.parseInt(converter[i][1]);
	    	binary[i] = actualID[i]*2+7960265728L+server[i];
	    
	    	fullformat[i] = "7656119" + Long.toString(binary[i]);
	    	binary[i] = Long.parseLong(fullformat[i]);
	    	
	    }
	    
	   
	    
	
	    
	    return binary;
    }
    public static String[] toLink(long[] result, int arrayLength)
    {
    	
    	
    	String[] links = new String[arrayLength];
    	for (int i = 0; i < result.length; i++)
    	{
    		links[i] = "https://steamcommunity.com/profiles/" + result[i];
    	}
    	return links;
    }
    public static void openWebPage(String[] url, String[] faceitUrl, String[] eseaUrl, int arrayLength)
    {
        try {
            Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
            if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) 
            {
            	for(int i = 0; i < arrayLength; i++)
            	{
            		desktop.browse(new URI(url[i]));
            		desktop.browse(new URI(faceitUrl[i]));
            		desktop.browse(new URI(eseaUrl[i]));
            		
            	}
            }
            throw new NullPointerException();
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, url, "", JOptionPane.PLAIN_MESSAGE);
        }
    }
    public static void main(String args[])  throws FileNotFoundException 
    {
    	 ArrayList<String> sidlist = new ArrayList<String>();
    	 
    	try
    	{
    		
    		File input = new File("input.txt");
    		if(input.createNewFile())
    		{
    			System.out.println("File created: " + input.getName());
    		}
    		else
    		{
    			System.out.println(input.getName() + " already exists");
    			
    			Scanner in = new Scanner(input);
        		while(in.hasNext())
        		{
        			String line = in.nextLine();
        			
        			Pattern pattern = Pattern.compile("(STEAM_\\d:\\d:\\d{1,})");
   				 	Matcher matcher = pattern.matcher(line);
        			while(matcher.find())
        			{
        				line = matcher.group(); 
        				sidlist.add(line);
        				
        			}
        		}
        		in.close();
    		}
    		
    	}
    	catch (IOException e) 
        {
    	      System.out.println("An error occurred.");
    	      e.printStackTrace();
        }
    	int arrayLength = sidlist.size();
    	System.out.println(arrayLength);
		String[] url = new String[arrayLength];
		String[] steamarray = new String[arrayLength];
		String[] faceitUrl = new String[arrayLength];
		String[] eseaUrl = new String[arrayLength];
		
		for(int i = 0; i < arrayLength; i++)
		{
			  steamarray[i] = sidlist.get(i);
			  //System.out.println(steamarray[i]);
		}
		
		long[] result = new long[arrayLength];
		
		result = toBinary(steamarray, arrayLength);   
		
	    url = toLink(result, arrayLength);
	    faceitUrl = findFaceit(result, arrayLength);
	    eseaUrl = findEsea(steamarray, arrayLength);
	    
	    
	    openWebPage(url,faceitUrl,eseaUrl, arrayLength);
	}
    
}
